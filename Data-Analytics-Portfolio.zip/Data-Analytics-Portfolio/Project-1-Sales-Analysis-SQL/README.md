# Project 1: Sales Analysis (SQL)
Detailed project information here.