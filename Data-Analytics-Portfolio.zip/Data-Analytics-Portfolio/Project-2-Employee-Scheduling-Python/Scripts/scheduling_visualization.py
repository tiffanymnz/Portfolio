# Python script for visualization
print('Creating visualizations...')