# Python script for data cleaning
print('Cleaning data...')