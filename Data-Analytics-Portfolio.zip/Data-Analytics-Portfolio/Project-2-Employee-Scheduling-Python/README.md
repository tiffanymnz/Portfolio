# Project 2: Employee Scheduling (Python)
Detailed project information here.