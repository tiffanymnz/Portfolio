# Project 3: Inventory Dashboard (Power BI)
Detailed project information here.